create definer = root@localhost view vw_colecao as
select `c`.`id`                AS `id`,
       `c`.`nomeColecao`       AS `nomeColecao`,
       `c`.`nomeColecaoIngles` AS `nomeColecaoIngles`,
       `c`.`sigla`             AS `sigla`,
       `c`.`qtdCards`          AS `qtdCards`,
       `c`.`qtdCardsReal`      AS `qtdCardsReal`,
       `c`.`idBloco`           AS `idBloco`,
       `b`.`nomeBloco`         AS `nomeBloco`,
       `b`.`nomeBlocoIngles`   AS `nomeBlocoIngles`,
       `c`.`numeroBloco`       AS `numeroBloco`
from (`pokemontcgcards`.`colecao` `c`
         join `pokemontcgcards`.`bloco` `b` on (`c`.`idBloco` = `b`.`id`));

