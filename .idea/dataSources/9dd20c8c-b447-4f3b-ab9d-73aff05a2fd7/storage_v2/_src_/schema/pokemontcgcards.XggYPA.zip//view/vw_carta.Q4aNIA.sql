create view vw_carta as
select `c`.`id`                 AS `id`,
       `c`.`nomeCarta`          AS `nomeCarta`,
       `c`.`nomeCartaIngles`    AS `nomeCartaIngles`,
       `c`.`numeroCarta`        AS `numeroCarta`,
       `c`.`idColecao`          AS `idColecao`,
       `c`.`flagTreinador`      AS `flagTreinador`,
       `c`.`flagItem`           AS `flagItem`,
       `c`.`flagApoiador`       AS `flagApoiador`,
       `c`.`idTipoPokemon`      AS `idTipoPokemon`,
       `c`.`fraqueza`           AS `fraqueza`,
       `c`.`resistencia`        AS `resistencia`,
       `c`.`idRaridade`         AS `idRaridade`,
       `c`.`idStatusPadrao`     AS `idStatusPadrao`,
       `c`.`idStatusExpandido`  AS `idStatusExpandido`,
       `co`.`nomeColecao`       AS `nomeColecao`,
       `co`.`nomeColecaoIngles` AS `nomeColecaoIngles`,
       `co`.`sigla`             AS `sigla`,
       `co`.`qtdCards`          AS `qtdCards`,
       `co`.`qtdCardsReal`      AS `qtdCardsReal`,
       `co`.`idBloco`           AS `idBloco`,
       `co`.`numeroBloco`       AS `numeroBloco`,
       `tp`.`descTipoPokemon`   AS `descTipoPokemon`,
       `r`.`descRaridade`       AS `descRaridade`,
       `s`.`descStatus`         AS `statusPadrao`,
       `st`.`descStatus`        AS `statusExpandido`
from (((((`pokemontcgcards`.`carta` `c` join `pokemontcgcards`.`colecao` `co` on (`co`.`id` = `c`.`idColecao`)) left join `pokemontcgcards`.`tipopokemon` `tp` on (`tp`.`id` = `c`.`idTipoPokemon`)) left join `pokemontcgcards`.`raridade` `r` on (`r`.`id` = `c`.`idRaridade`)) left join `pokemontcgcards`.`status` `s` on (`s`.`id` = `c`.`idStatusPadrao`))
         left join `pokemontcgcards`.`status` `st` on (`st`.`id` = `c`.`idStatusExpandido`));

